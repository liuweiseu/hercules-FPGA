Introduction：
- h6_sim_lib：simulation library related files
including: 
1. h1d03 simulation library file h6_sim.v
2. mipi_host.v, MIPI host behavior module (only support part of the IP function, used for MIPI IP user interface simulation)
3. mipi_slave.v, MIPI slave behavior module
4. pattern_gen.v, generate DVP RGB output signals
- TestBench： top testbench file
- video_packege：verilog design based on MIPI packet interface, can be used as MIPI packet interface design reference code


	
